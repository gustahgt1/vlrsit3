const players = [
  {name:"FALLENX", role:"Duelista", rank:"Immortal 3", overall:92, aim:91, hs:88, kd:1.42},
  {name:"KRYPT", role:"Controlador", rank:"Ascendente 3", overall:89, aim:87, hs:79, kd:1.31},
  {name:"NOVA", role:"Iniciador", rank:"Immortal 2", overall:87, aim:86, hs:82, kd:1.24},
  {name:"VEX", role:"Sentinela", rank:"Immortal 1", overall:85, aim:84, hs:76, kd:1.19},
  {name:"Z3RO", role:"Duelista", rank:"Ascendente 3", overall:83, aim:89, hs:74, kd:1.16},
  {name:"M4X", role:"Controlador", rank:"Ascendente 2", overall:81, aim:80, hs:71, kd:1.11},
  {name:"RUSH", role:"Duelista", rank:"Diamante 3", overall:78, aim:85, hs:69, kd:1.08},
  {name:"ECHO", role:"Iniciador", rank:"Diamante 3", overall:76, aim:78, hs:73, kd:1.02},
  {name:"ONYX", role:"Sentinela", rank:"Diamante 2", overall:73, aim:75, hs:68, kd:.98}
];

const data = {
  Jogador:["FALLENX","KRYPT","NOVA","VEX","Z3RO","M4X","RUSH","ECHO","ONYX"],
  Agente:["Jett","Raze","Omen","Sova","Cypher","Neon","Clove","Gekko"],
  Arma:["Vandal","Phantom","Operator","Sheriff","Classic","Guardian"],
  Mapa:["Ascent","Bind","Haven","Lotus","Sunset","Icebox"],
  Desafio:["Só HS","Sem HUD","Trocar de arma","Eco round","Só Sheriff","Primeiro abate"]
};
let category="Jogador", spinning=false, rotation=0;

const $=s=>document.querySelector(s);
const initials=n=>n.slice(0,2);
const playerCard=p=>`
<article class="player-item">
  <div class="avatar">${initials(p.name)}</div>
  <div><h3>${p.name}</h3><small>${p.role} · ${p.rank}</small></div>
  <div class="player-ovr">${p.overall}</div>
</article>`;

function renderOverall(){
  $("#overallGrid").innerHTML=players.slice(0,6).map(p=>`
  <article class="overall-card">
    <div class="oc-head"><small>${p.role.toUpperCase()}</small><small>${p.rank}</small></div>
    <div class="oc-main"><h3>${p.name}</h3><div class="oc-score">${p.overall}</div></div>
    <div class="oc-label"><span>OVERALL</span><b>${p.overall}/100</b></div><div class="bar"><i style="width:${p.overall}%"></i></div>
    <div class="oc-label"><span>AIM</span><b>${p.aim}</b></div><div class="bar"><i style="width:${p.aim}%"></i></div>
  </article>`).join("");
}
function renderPlayers(list=players){$("#playerGrid").innerHTML=list.length?list.map(playerCard).join(""):`<p style="color:var(--muted)">Nenhum jogador encontrado.</p>`}
function renderRanking(){
  $("#rankingBody").innerHTML=[...players].sort((a,b)=>b.overall-a.overall).map((p,i)=>`
  <tr><td>${String(i+1).padStart(2,"0")}</td><td>${p.name}</td><td><span class="rank-pill">${p.rank}</span></td><td class="td-ovr">${p.overall}</td><td>${p.aim}</td><td>${p.hs}%</td><td>${p.kd}</td></tr>`).join("");
}
function renderStats(){
  const avg=Math.round(players.reduce((s,p)=>s+p.overall,0)/players.length);
  const aim=players.reduce((a,b)=>a.aim>b.aim?a:b), kd=players.reduce((a,b)=>a.kd>b.kd?a:b), hs=players.reduce((a,b)=>a.hs>b.hs?a:b);
  $("#avgOverall").textContent=avg;$("#bestAim").textContent=aim.aim;$("#bestAimName").textContent=aim.name;
  $("#bestKD").textContent=kd.kd;$("#bestKDName").textContent=kd.name;$("#bestHS").textContent=hs.hs+"%";$("#bestHSName").textContent=hs.name;
}
function renderCategories(){
  $("#categoryButtons").innerHTML=Object.keys(data).map(k=>`<button class="cat-btn ${k===category?"active":""}" data-cat="${k}">${k}</button>`).join("");
}
function spin(){
  if(spinning)return;spinning=true;$("#spinBtn").disabled=true;
  const items=data[category], result=items[Math.floor(Math.random()*items.length)];
  rotation += 1440 + Math.floor(Math.random()*360);
  $("#wheel").style.transform=`rotate(${rotation}deg)`;
  setTimeout(()=>{ $("#rouletteResult").innerHTML=`<small>${category.toUpperCase()}</small><strong>${result}</strong><span>${category==="Desafio"?"Boa sorte no desafio.":"Essa foi a escolha do LAB."}</span>`;spinning=false;$("#spinBtn").disabled=false; },3400);
}
function compare(){
  const a=players.find(p=>p.name===$("#compareA").value),b=players.find(p=>p.name===$("#compareB").value);
  if(!a||!b)return;
  $("#compareResult").innerHTML=`<div class="compare-side"><h4>${a.name}</h4><p>OVERALL ${a.overall}</p><i><span style="width:${a.overall}%"></span></i><p>AIM ${a.aim}</p><i><span style="width:${a.aim}%"></span></i><p>HS ${a.hs}% · K/D ${a.kd}</p></div><div class="compare-vs">VS</div><div class="compare-side"><h4>${b.name}</h4><p>OVERALL ${b.overall}</p><i><span style="width:${b.overall}%"></span></i><p>AIM ${b.aim}</p><i><span style="width:${b.aim}%"></span></i><p>HS ${b.hs}% · K/D ${b.kd}</p></div>`;
}
function init(){
  renderOverall();renderPlayers();renderRanking();renderStats();renderCategories();
  const options=players.map(p=>`<option>${p.name}</option>`).join("");$("#compareA").innerHTML=options;$("#compareB").innerHTML=options;$("#compareB").selectedIndex=1;compare();
  $("#playerSearch").addEventListener("input",e=>{const q=e.target.value.toLowerCase();renderPlayers(players.filter(p=>p.name.toLowerCase().includes(q)||p.role.toLowerCase().includes(q)||p.rank.toLowerCase().includes(q)))});
  $("#spinBtn").addEventListener("click",spin);
  $("#categoryButtons").addEventListener("click",e=>{if(e.target.dataset.cat){category=e.target.dataset.cat;renderCategories();}});
  $("#compareA").addEventListener("change",compare);$("#compareB").addEventListener("change",compare);
  $("#mobileMenu").addEventListener("click",()=>$("#mainNav").classList.toggle("open"));
  document.querySelectorAll("nav a").forEach(a=>a.addEventListener("click",()=>$("#mainNav").classList.remove("open")));
}
init();
